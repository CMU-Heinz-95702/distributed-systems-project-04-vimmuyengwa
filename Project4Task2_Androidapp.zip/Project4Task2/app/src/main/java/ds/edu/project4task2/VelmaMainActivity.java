package ds.edu.project4task2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.*;

/*
 * Name: Vimbai Muyengwa
 * andrewID: vmuyengw
 *
 * VelmaMainActivity.java - Native Android application that displays top-rated video games.
 *
 * This activity is the main entry point for the Velma app, where users can:
 * - Input a game genre.
 * - Tap a button to get recommendations.
 * - View the top 3 games based on Metacritic score.
 *
 * Implementation details:
 * a. Has at least three different kinds of Views in the layout:
 *    - TextView for output and labels
 *    - EditText for user input
 *    - ImageView to display an image of the top game
 * b. Requires input from the user
 * c. Makes an HTTP request (using an appropriate HTTP method) to the web service.
 *    - This request is done using a background thread (see Lab 8's use of BackgroundTask).
 * d. Receives and parses a JSON formatted reply from the web service
 * e. Displays new information to the user
 * f. Is repeatable (i.e., the user can repeatedly reuse the application without restarting it)
 *
 * The activity calls the RecommendationsGetter to make network requests,
 * and implements RecommendationCallback to receive parsed game data.
 *
 * sources:
 * Android Lab 8
 * Lab 8 Code: https://github.com/CMU-Heinz-95702/lab8-AndroidInterestingPicture?tab=readme-ov-file
 *  https://developer.android.com/reference/java/net/HttpURLConnection
 *
 * GenAI used for troubleshoot and code generation
 */

public class VelmaMainActivity extends AppCompatActivity implements RecommendationCallback {

    private EditText genreInput;
    private TextView resultsText;

    //private ImageView previewImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);  // Or activity_main if you use that wrapper

        genreInput = findViewById(R.id.genreInput);
        resultsText = findViewById(R.id.resultsText);
        //previewImage = findViewById(R.id.previewImage);

        // Button to trigger game recommendations (requirement a: a distinct View type)
        Button getGamesButton = findViewById(R.id.getGamesButton);

        // Set listener for button click
        getGamesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input from user, clean and normalize to lowercase (removes case sensitivity)
                String genre = genreInput.getText().toString().trim().toLowerCase();

                // Validate input before sending to web service
                if (!genre.isEmpty()) {
                    // c: Makes an HTTP request to your web service
                    //    This request must be done using a background thread
                    RecommendationsGetter getter = new RecommendationsGetter();
                    getter.search(genre, VelmaMainActivity.this, VelmaMainActivity.this);
                } else {
                    resultsText.setText("Please enter a genre.");
                 //  comment out not fitting nicely previewImage.setVisibility(ImageView.GONE);
                }
            }
        });


    }

// will uncomment if I can fit image and it not crowded
//    public void recommendationReady(String name, Bitmap image) {
//        if (name != null && !name.isEmpty()) {
//            resultsText.setText(name);
//            if (image != null) {
//                previewImage.setImageBitmap(image);
//                previewImage.setVisibility(ImageView.VISIBLE);
//            } else {
//                previewImage.setVisibility(ImageView.GONE);
//            }
//        } else {
//            resultsText.setText("No game match or there is an error.");
//            previewImage.setVisibility(ImageView.GONE);
//        }


    /*
     * This method receives data once the background thread completes.
     * d: Receives and parses a JSON formatted reply from your web service
     * e: Displays new information to the user
     */
    @Override
public void recommendationReady(String name, Bitmap image) {
    if (name != null && !name.isEmpty()) {
        resultsText.setText(name); //display 3 names
    } else {
        //requirement 3: Handle error conditions
        resultsText.setText("No game match or there is an error.");
    }
}

}


