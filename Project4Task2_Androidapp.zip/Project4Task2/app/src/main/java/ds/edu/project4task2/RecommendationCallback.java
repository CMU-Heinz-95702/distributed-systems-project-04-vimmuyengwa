package ds.edu.project4task2;

import android.graphics.Bitmap;

public interface RecommendationCallback {

    /*
     * Author: Vimbai Muyengwa
     * andrewID: vmuyengw
     * Callback method triggered when the recommendation data is ready.
     *
     * @param name   A String containing the top 3 game names & Metacritic scores.
     * @param image Bitmap not used (removed)
     *
     *
     *
     * e. Displays new information to the user — this method is called on the UI thread.
     * f. This pattern supports repeatability
     */
    void recommendationReady(String name, Bitmap image);  // matches implementation
}

