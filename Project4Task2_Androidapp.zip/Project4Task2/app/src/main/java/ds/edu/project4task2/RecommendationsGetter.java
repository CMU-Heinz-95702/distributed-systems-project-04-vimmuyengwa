package ds.edu.project4task2;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/*
 * Name: Vimbai Muyengwa
 * andrewID: vmuyengw
 *
 * RecommendationsGetter.java - Helper class that performs HTTP requests to fetch top-rated games.
 *
 * This class is responsible for:
 * - Making an HTTP GET request to a cloud-based web service endpoint.
 * - Executing the request on a background thread (see Lab 8's use of BackgroundTask).
 * - Receiving and parsing a JSON-formatted reply from the web service.
 * - Returning the result through a callback interface.
 *
 * The response includes the top 3 games based on Metacritic score for a given genre,
 * and optionally includes an image for the top game.
 *
 * Responsibilities:
 * - Manages background thread execution using an inner BackgroundTask class.
 * - Builds the request URL using the selected genre.
 * - Sets custom headers (e.g., device model) to support logging on the server.
 * - Parses structured JSON data and passes it to the UI via the RecommendationCallback.
 *
 * - Handles errors such as network failure or empty results.
 *
 * Author: Vimbai Muyengwa
 * AndrewID: vmuyengw
 *
 * References: Lab 8 Code: https://github.com/CMU-Heinz-95702/lab8-AndroidInterestingPicture?tab=readme-ov-file
       https://developer.android.com/reference/java/net/HttpURLConnection
        GenAI used for troubleshoot
 */

public class RecommendationsGetter {

    private RecommendationCallback callback;
    private String genre;

    public void search(String genre, Activity activity, RecommendationCallback callback) {
        this.genre = genre;
        this.callback = callback;
        new BackgroundTask(activity).execute();  // Pass activity to inner class
    }

    // Inner class to handle background operations (network + parsing)
    private class BackgroundTask {

        private final Activity activity; // Reference to main activity for UI updates

        // Stores top 3 games' names, metacritic scores
        private StringBuilder topGamesText = new StringBuilder();
        private Bitmap previewImage = null; //(not used)

        /*
         * Constructor that accepts the activity context.
         * Used later to run UI updates on the main thread.
         */
        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        public void execute() {
            // Create and start a new background thread to avoid blocking the UI thread
            new Thread(new Runnable() {
                @Override
                public void run() {
                    // Perform background work: network request and parsing
                    doInBackground();

                    // After background work is complete, update the UI safely
                    onPostExecute();  // This method should internally switch to UI thread if needed
                }
            }).start();
        }

        /*
         * Author: Vimbai Muyengwa
         * andrewID: vmuyengw
         * Performs the core functionality of the Velma app in a background thread.
        *
        * This method:
        * - Builds a URL with the user's selected genre
        * - (c) Sends an HTTP GET request to a web service running in GitHub Codespaces
        * - Reads and collects the JSON response from the server
        * - (d) Parses the JSON to extract details for the top 3 games (name, metacritic score, slug)
        * - (e) Updates the UI to display new game recommendations to the user
        * - (f) Supports repeatable use: the method is called every time the user enters a new genre
        *
        * This background execution ensures that the app remains responsive and complies
        *
        * References: Lab 8 Code: https://github.com/CMU-Heinz-95702/lab8-AndroidInterestingPicture?tab=readme-ov-file
        *  https://developer.android.com/reference/java/net/HttpURLConnection
        * GenAI used for troubleshoot
        */
        private void doInBackground() {
            try {
                // Question 1, C: Makes an HTTP request (using an appropriate HTTP method) to your web service
                String servletCodeSpaceUrl = "https://supreme-rotary-phone-5gj6qqvjp79c9p6-8080.app.github.dev/getGames?genre=" + genre;
                Log.d("VELMA_FETCH", "Retrieve from URL: " + servletCodeSpaceUrl); //inserted after trouble shoot

                URL url = new URL(servletCodeSpaceUrl); //Set up URL connection and define request method
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET"); //HTTP Get method

                //troubleshoot used GENAI
                conn.setRequestProperty("X-Device-Model", "Android " + android.os.Build.MODEL);

                // Open a stream to read the incoming response line by line
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                // Use StringBuilder to accumulate the entire JSON response as one string
                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseBuilder.append(line);
                }
                reader.close(); // Close the stream after reading is complete

                // Question 1 (d): Parse the JSON formatted reply from the web service
                JSONObject jsonResponse = new JSONObject(responseBuilder.toString()); // Convert string to JSON object
                JSONArray games = jsonResponse.getJSONArray("games"); // Extract the games array from the JSON

                if (games.length() == 0) { // Handle case where no games were returned
                    topGamesText.append("Zero games in this genre.");
                    return;
                }

                //Limits to top 3 games
                int count = Math.min(3, games.length());
                for (int i = 0; i < count; i++) {
                    JSONObject game = games.getJSONObject(i); // Get each game object

                    // Safe extract game fields with fallback/default values
                    String name = game.optString("name", "Unknown");
                    String metacritic = game.has("metacritic") ? String.valueOf(game.getInt("metacritic")) : "N/A";
                    String slug = game.optString("slugID", "N/A");

                    // Question 1, e: Display each game’s rank and detail
                    // Display parsed game information to the user in the UI
                    topGamesText.append("Rank ").append(i + 1).append(":\n")
                            .append("Name: ").append(name).append("\n")
                            .append("Metacritic: ").append(metacritic).append("\n")
                            .append("SlugID: ").append(slug).append("\n\n");

                }
                //try, catch exception
            } catch (Exception e) {
                Log.e("VELMA_FETCH", "Exception during fetch", e); //inserted after troubleshoot issues
                topGamesText.append("Data fetch failure.");
            }
        }
        private void onPostExecute() {
            // Ensure UI updates are performed on the main (UI) thread
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Log a debug message to confirm UI update is happening
                    Log.d("GAME_UI", "onPostExecute: updating UI on main thread");

                    // e: Displays new information to the user
                    // Trigger the callback to send the processed data (game names and preview image)
                    // back to the main activity so the UI can be updated
                    callback.recommendationReady(topGamesText.toString(), previewImage);
                }
            });
        }
    }
}