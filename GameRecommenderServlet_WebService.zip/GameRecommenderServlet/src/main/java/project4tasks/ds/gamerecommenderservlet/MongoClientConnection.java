package project4tasks.ds.gamerecommenderservlet;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import com.mongodb.client.*;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



/*
 * Student: Vimbai Muyengwa
 * AndrewID: vmuyengw
 * Web Service Logging and Analysis Dashboard Servlet
 *
 * This servlet supports the web-based dashboard that displays logs and analytics for the Velma game recommendation app.
 * As required by the project:
 * - This dashboard is a web page interface for use from a desktop or laptop browser (not a mobile device).
 * - It displays two types of data: logs and operations analytics.
 * - Logs are retrieved from a MongoDB database hosted in the cloud.
 * - Analytics include top genres, request volume over time, and average latency.
 *
 * GenAI (ChatGPT) was used to assist with troubleshooting and code generation.
 */
@WebServlet("/dashboard")
public class MongoClientConnection extends HttpServlet {
    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;

    /*
     * Initializes the servlet and connects to MongoDB database.
     * stores my log data persistently so that it is available across restarts of the application.
     */
    @Override
    public void init() throws ServletException {
        super.init();
        try {
            String uri = "mongodb+srv://vmuyengw:2Dzidzayi$$@cluster0.jppey.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
            mongoClient = MongoClients.create(uri);
            MongoDatabase database = mongoClient.getDatabase("velmaGameApp");
            logCollection = database.getCollection("logs");

            System.out.println("Pinged your deployment. You successfully connected to MongoDB");

        } catch (Exception e) {
            System.err.println(" MongoDB connection failed:");
            e.printStackTrace();
        }
    }

    /*
     * Closes the MongoDB client connection on servlet shutdown.
     */
    @Override
    public void destroy() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }

    /*
     * Handles GET requests to the /dashboard endpoint.
     * As required:
     * - Displays at least 3 interesting operations analytics
     * - Displays the logs in a human-readable HTML table
     */
    @Override
    protected void doGet(HttpServletRequest servletRequest, HttpServletResponse servletResponse) throws ServletException, IOException {

        // Get all logs
        List<Document> logs = logCollection.find().into(new ArrayList<>());

        // Top 2 most searched genres
        // Supports operations analytics showing most popular user input
        AggregateIterable<Document> topGenres = logCollection.aggregate(List.of(
                Aggregates.group("$appRequestParameters", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(2) // updated to top 2
        ));

        List<Document> genreStats = new ArrayList<>();
        topGenres.forEach(genreStats::add);


        //  Average latency per day
        AggregateIterable<Document> avgLatencyPerDay = logCollection.aggregate(List.of(
                Aggregates.project(Projections.fields(
                        Projections.computed("dateOnly", new Document("$substr", List.of("$requestReceivedTimestamp", 0, 10))),
                        Projections.include("latency")
                )),
                Aggregates.group("$dateOnly", Accumulators.avg("avgLatency", "$latency")),
                Aggregates.sort(Sorts.ascending("_id"))
        ));

        // Collect the daily averages into a list for use 
        List<Document> latencyStats = new ArrayList<>();
        avgLatencyPerDay.forEach(latencyStats::add);

        // Count total requests for display on the dashboard
        long totalRequests = logCollection.countDocuments();
        servletRequest.setAttribute("totalRequests", totalRequests);

        // Calculate the average latency for all time
        // Group all requests together and compute the overall average latency
        double avgLatencyOverall = 0.0;
        AggregateIterable<Document> avgLatency = logCollection.aggregate(List.of(
                Aggregates.group(null, Accumulators.avg("avgLatency", "$latency"))
        ));
        for (Document stat : avgLatency) {
            if (stat.get("avgLatency") != null) {
                avgLatencyOverall = ((Number) stat.get("avgLatency")).doubleValue();
            }
        }
        servletRequest.setAttribute("avgLatencyOverall", avgLatencyOverall);

        // Set logs and analytics attributes to be displayed in the JSP dashboard
        servletRequest.setAttribute("logs", logs);
        servletRequest.setAttribute("genreStats", genreStats);
        //(don't want to include the below anymore. I have 3 already)
        // servletRequest.setAttribute("requestStats", requestStats);
        servletRequest.setAttribute("latencyStats", latencyStats);

        // Forward request to JSP for rendering
        // JSP will use HTML tables to present logs and analytics in a readable format
        servletRequest.getRequestDispatcher("/dashboard.jsp").forward(servletRequest, servletResponse);
    }
}