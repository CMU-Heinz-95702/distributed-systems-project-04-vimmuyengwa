package project4tasks.ds.gamerecommenderservlet;


import java.io.*;
import java.net.*;
import java.time.Instant;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/*
Student: Vimbai Muyengwa
andrewID: vmuyengw

 * GameRecommendationServlet
 *
 * This servlet implements a simple web service that receives HTTP GET requests from a native Android application,
 * fetches top 3 game recommendations from the RAWG third-party API (based on a provided genre), processes the JSON
 * response to extract only the essential fields (name, metacritic score, slug), and returns a trimmed-down JSON
 * response to the client. It also logs detailed request/response information to MongoDB for dashboard analytics.
 *
 * This servlet satisfies the following:
 * a. Implements a single-path API: /getGames
 * b. Receives requests from a mobile app (Android)
 * c. Executes business logic by calling a 3rd-party API (RAWG) and processes JSON
 * d. Replies with a clean JSON response (with only needed data)
 * e. Logs 6+ analytics fields to MongoDB for dashboard display

 References:
    RAWG. (n.d.). RAWG API documentation. https://rawg.io/apidocs
    https://github.com/CMU-Heinz-95702/Project4/blob/master/README.md
     Mongo Bison information et al.

    Previous lab2 for servlet functionality Review
 GenAI chatGPT used for troubleshoot and code generation
*/


// Implement a simple can be a single path API
@WebServlet("/getGames")
public class GameRecommendationServlet extends HttpServlet {

    // API key for authenticating requests to the RAWG API
    private final String API_KEY = "19456881592b452f998b624c2fbd70ca";
    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm:ss").withZone(ZoneId.systemDefault());


    @Override // Handles HTTP GET requests sent to /getGames
    protected void doGet(HttpServletRequest servletRequest, HttpServletResponse servletResponse) throws IOException {

        servletResponse.setContentType("application/json"); //Set the response content type to application/json

        // Get and read genre from request parameter
        // This is input from the user (Android app)
        String genre = servletRequest.getParameter("genre");
        if (genre != null) {
            genre = genre.trim().toLowerCase(); // Normalize genre input to lowercase
        }

        //Used GenAI to for troubleshoot help with date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm:ss")
                .withZone(ZoneId.of("America/New_York"));

        //track time
        String requestReceivedTimestamp = formatter.format(Instant.now());

        long startTime = System.currentTimeMillis();

        //// Handle missing or invalid input from the client
        //Invalid mobile app input
        if (genre == null || genre.trim().isEmpty()) {
            servletResponse.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            servletResponse.getWriter().write("{\"error\": \"Genre missing\"}");
            return;
        }

        try { //try-catch block if 3rd party API is unavailable
            /* Fetch top games from RAWG API: Executes business logic appropriate to my application
            // Fetching JSON information from a 3rd party API
            Retrive top 3 games
             */
            String rawGUrl = "https://api.rawg.io/api/games?key=" + API_KEY + "&genres=" + genre + "&page_size=3&ordering=-metacritic";

            String thirdPartyApiRequestTimestamp = formatter.format(Instant.now()); //// Timestamp for when 3rd-party API request is made

            URL url = new URL(rawGUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // Read the response from the RAWG API into a StringBuilder
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder responseBuilder = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                responseBuilder.append(line);
            }
            reader.close();

            //troubleshoot code
           // System.out.println("RAWG RESPONSE: " + responseBuilder.toString());

            // Parse the JSON response into a JsonObject
            JsonObject jsonResponse = JsonParser.parseString(responseBuilder.toString()).getAsJsonObject();
            JsonArray gameResults = jsonResponse.getAsJsonArray("results"); // // Extract the array of game results

            // Handle case where RAWG API returns no results (invalid or rare genre)
            if (gameResults == null || gameResults.size() == 0) {
                servletResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
                servletResponse.getWriter().write("{\"error\": \"No games found for the genre '" + genre + "'. Try a different genre.\"}");
                return;
            }

            // Construct a simplified JSON response. Replies to the Android application with a JSON formatted response
            JsonArray essentialGameData = new JsonArray();

            // Loop through each game in the results (top 3)
            for (int i = 0; i < gameResults.size(); i++) {
                JsonObject gameDetails = gameResults.get(i).getAsJsonObject();
                JsonObject essentialData = new JsonObject();

                // Add cleaned-up game data to the new JSON object
                //https://api.rawg.io/docs/#operation/games_suggested_read
                //pulls essential data for Game
                essentialData.addProperty("Game Rank", i + 1); // 1 based ranking
                essentialData.addProperty("name", gameDetails.get("name").getAsString());

                // Check if metacritic rating exists before adding
                // checks if Third-Party API Returns Invalid Data
                if (gameDetails.has("metacritic") && !gameDetails.get("metacritic").isJsonNull()) {
                    essentialData.addProperty("metacritic", gameDetails.get("metacritic").getAsDouble());
                } else {
                    essentialData.addProperty("metacritic", -1); // default if unavailable
                }
                essentialData.addProperty("slugID", gameDetails.get("slug").getAsString()); //An ID or a slug identifying this Game per API rawg.io/docs
                essentialGameData.add(essentialData);

                // Add image URL if available
//                if (gameDetails.has("background_image") && !gameDetails.get("background_image").isJsonNull()) {
//                    essentialData.addProperty("image", gameDetails.get("background_image").getAsString());
//                }
            }


            // Wrap the array in a parent JSON object
            JsonObject finalResponse = new JsonObject(); // Create JSON object to return to Android client
            finalResponse.add("games", essentialGameData);

            // Send the successful 200 OK response to the client with the JSON data
            servletResponse.setStatus(HttpServletResponse.SC_OK);
            servletResponse.getWriter().write(finalResponse.toString());

            /*
            * Dashboard Logging
            *The purpose of logging data to the database is to be able to create an operations dashboard for your web service.
            * This dashboard should be web page interface for use from a desktop or laptop browser (not a mobile device).
            * The dashboard should display two types of data: 3.1. Operations analytics – display at least 3 interesting operations analytics from your web service.
            * You should choose analytics that are relevant to your specific web service. Examples for InterestingPicture might be top 10 picture search terms, average Flickr search latency, or the top 5 Android phone models making requests.
            * 3.2. Logs – display the data logs being stored for each mobile phone user interaction with your web service
            *
             */
            //Logging to MongoDB
            long endTime = System.currentTimeMillis();
            long latency = endTime - startTime;

            //  // Get metadata from request (device model)
            String phoneModel = servletRequest.getHeader("Device Model");
            if (phoneModel == null || phoneModel.trim().isEmpty()) { // error response if phone model is null
                phoneModel = "N/A, This is via Web Client";
            }
            String appParams = "genre=" + genre;

            //construct log fields
            // Loop through each element in the essentialGameData list.
            StringBuilder replyData = new StringBuilder(); //stringbuilder for replyData
            for (int i = 0; i < essentialGameData.size(); i++) {
                JsonObject game = essentialGameData.get(i).getAsJsonObject();

                // Extract the "name" property from the game object as a string
                // and append it to the replyData string being built.
                replyData.append(game.get("name").getAsString());
                if (i < essentialGameData.size() - 1) replyData.append(", ");
            }

            String replyInfo = "Status: 200 OK | Games Returned: " + essentialGameData.size(); //reply status

            // Build LoggingData object for Mongo DB. Persists log to mongo db
            // track overall performance with latency measures for the requests for specific genres
            LoggingData log = new LoggingData(
                    phoneModel,
                    appParams, // the appParams are the genres
                    requestReceivedTimestamp,
                    thirdPartyApiRequestTimestamp,
                    replyData.toString(),
                    replyInfo,
                    latency
            );

            // Insert into MongoDB using login credentials
            MongoClient mongoClient = MongoClients.create("mongodb+srv://vmuyengw:2Dzidzayi$$@cluster0.jppey.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
            MongoDatabase database = mongoClient.getDatabase("velmaGameApp"); //// Access the specific MongoDB database named 'velmaGameApp'
            MongoCollection<org.bson.Document> logCollection = database.getCollection("logs"); //// Access the collection named 'logs' within the 'velmaGameApp' database

            logCollection.insertOne(log.toDocument()); //// Insert the current request's log data as a new document into the collection

            mongoClient.close();

        } catch (Exception e) {
            // Handle 3rd-party API unavailable or invalid data
            servletResponse.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            servletResponse.getWriter().write("{\"error\": \"Something went awry. Try again later.\"}");
            e.printStackTrace();
        }
    }
}
