package project4tasks.ds.gamerecommenderservlet;

import org.bson.Document;

/*
 * Name: Vimbai Muyengwa
 * andrewid: vmuyengw
 *
 * Logging:
 *
 * Information can include such parameters as what kind of model of phone has made the request,
 * parameters included in the request specific to your application,
 * timestamps for when requests are received,
 * requests sent to the 3rd party API, and
 * the data sent in the reply back to the phone.
 * Per instructions: this tracks at least 6 pieces of information that would be useful for including in a dashboard
 *  for your application. It should include information about the request from the mobile phone,
 *  information about the request and reply to the 3rd party API, and information about the reply to the mobile phone.
 *
 *  GenAI used for troubleshoot (chatGpt) and code generation
*/
public class LoggingData {
    private String phoneModel; //hat kind of model of phone has made the request,
    private String specificAppRequestParameters; //parameters included in the request specific to your application,
    private String timestampForRequestReceipt; // timestamps for when requests are received
    private String thirdPartyApiRequestTimestamp;
    private String dataReplyMobile; // requests sent to the 3rd party API,
    private String mobilePhoneInfoReply; // the data sent in the reply back to the phone.
    private long latency; //latency information

    /*
     * Constructor to initialize all logging fields.
     *
     * @param phoneModel                   The device making the request
     * @param appRequestParameters         The specific request parameters from the app
     * @param requestReceivedTimestamp     Time the server received the request
     * @param thirdPartyApiRequestTimestamp Time the 3rd-party API was called
     * @param thirdPartyApiReplyData       Data returned from RAWG and forwarded to app
     * @param replyToMobilePhoneInfo       Status/summary sent back to app
     * @param latency                      Time taken to process the full request
     */
    public LoggingData(String phoneModel, String appRequestParameters,
                    String requestReceivedTimestamp, String thirdPartyApiRequestTimestamp,
                    String thirdPartyApiReplyData, String replyToMobilePhoneInfo,
                    long latency) {
        this.phoneModel = phoneModel;
        this.specificAppRequestParameters = appRequestParameters;
        this.timestampForRequestReceipt = requestReceivedTimestamp;
        this.thirdPartyApiRequestTimestamp = thirdPartyApiRequestTimestamp;
        this.dataReplyMobile = thirdPartyApiReplyData;
        this.mobilePhoneInfoReply = replyToMobilePhoneInfo;
        this.latency = latency;
    }

    /*
     * Converts the log data into a MongoDB BSON document for insertion into the database.
     *
     * @return Document representing the log entry
     */
    public Document toDocument() {
        return new Document("phoneModel", phoneModel)
                .append("appRequestParameters", specificAppRequestParameters)
                .append("requestReceivedTimestamp", timestampForRequestReceipt)
                .append("thirdPartyApiRequestTimestamp", thirdPartyApiRequestTimestamp)
                .append("thirdPartyApiReplyData", dataReplyMobile)
                .append("replyToMobilePhoneInfo", mobilePhoneInfoReply)
                .append("latency", latency);
    }
}